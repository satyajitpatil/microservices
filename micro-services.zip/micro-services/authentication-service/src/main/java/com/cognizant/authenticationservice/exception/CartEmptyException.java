package com.cognizant.authenticationservice.exception;

@SuppressWarnings("serial")
public class CartEmptyException extends Exception {

	public CartEmptyException() {

		System.out.println(" Cart is Empty");

	}
}
