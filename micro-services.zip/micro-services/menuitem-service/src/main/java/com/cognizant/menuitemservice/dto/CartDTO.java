package com.cognizant.menuitemservice.dto;

import java.util.List;

import com.cognizant.menuitemservice.model.MenuItem;


public class CartDTO {
	private List<MenuItem> cartItems;
	private double total;

	public CartDTO() {
		super();
	}

	public CartDTO(List<MenuItem> cartItems, double total) {
		super();
		this.cartItems = cartItems;
		this.total = total;
	}


	public List<MenuItem> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<MenuItem> cartItems) {
		this.cartItems = cartItems;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Cart [menuItemList=" + cartItems + ", total=" + total + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cartItems == null) ? 0 : cartItems.hashCode());
		long temp;
		temp = Double.doubleToLongBits(total);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartDTO other = (CartDTO) obj;
		if (cartItems == null) {
			if (other.cartItems != null)
				return false;
		} else if (!cartItems.equals(other.cartItems))
			return false;
		if (Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
			return false;
		return true;
	}

}
